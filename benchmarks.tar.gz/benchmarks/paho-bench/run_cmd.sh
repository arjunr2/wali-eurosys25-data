sudo docker run --network=host paho-img --broker=hc-00.arena.andrew.cmu.edu --pub=topic --sub=topic 
