for (( i=0; i < $@; i++))
do
    echo "$i" > /dev/null
done
